// lib/features/forms/dynamic_form_page.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Single form state for this page instance.
/// If you ever need multiple forms on-screen simultaneously, migrate this to a `.family`.
final formStateProvider =
StateProvider.autoDispose<Map<String, dynamic>>((ref) => <String, dynamic>{});

class DynamicFormPage extends ConsumerStatefulWidget {
  const DynamicFormPage({
    super.key,
    this.formId,
    this.title,
    this.initialValues, // <-- added to match router usage
    this.onSubmit,      // optional: plug your submission service
  });

  /// Optional identifier for the form (e.g., route param)
  final String? formId;

  /// Optional title override
  final String? title;

  /// Optional initial values to seed the form. Expected keys:
  /// 'fullName', 'email', 'phone', 'requirement' (free text)
  final Map<String, dynamic>? initialValues;

  /// Optional submit hook. If null, page shows a success snackbar and pops.
  final Future<void> Function(Map<String, dynamic> values)? onSubmit;

  @override
  ConsumerState<DynamicFormPage> createState() => _DynamicFormPageState();
}

class _DynamicFormPageState extends ConsumerState<DynamicFormPage> {
  final _formKey = GlobalKey<FormState>();

  // Controllers prevent keyboard flicker and keep cursor position stable.
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();

    // Seed provider + controllers once, after widget is ready.
    Future.microtask(() {
      final seed = <String, dynamic>{
        'fullName': (widget.initialValues?['fullName'] as String?) ?? '',
        'email': (widget.initialValues?['email'] as String?) ?? '',
        'phone': (widget.initialValues?['phone'] as String?) ?? '',
        'requirement': (widget.initialValues?['requirement'] as String?) ?? '',
        'formId': widget.formId,
      };

      // Merge with any existing state (should be empty on first open due to autoDispose).
      ref.read(formStateProvider.notifier).update((prev) => <String, dynamic>{
        ...prev,
        ...seed,
      });

      // Initialize controllers from seeded state
      _nameCtrl.text = seed['fullName'] as String;
      _emailCtrl.text = seed['email'] as String;
      _phoneCtrl.text = seed['phone'] as String;
      _notesCtrl.text = seed['requirement'] as String;
    });
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  void _updateField(String key, String value) {
    ref.read(formStateProvider.notifier).update(
          (prev) => <String, dynamic>{...prev, key: value},
    );
  }

  Future<void> _handleSubmit() async {
    if (!_formKey.currentState!.validate()) return;

    final values = ref.read(formStateProvider);

    try {
      if (widget.onSubmit != null) {
        await widget.onSubmit!(values);
      } else {
        // TODO: Replace this with your SubmissionService if desired, e.g.:
        // await SubmissionService.instance.submit(values['formId'] as String?, values);
        await Future<void>.delayed(const Duration(milliseconds: 200));
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Submitted successfully')),
      );

      Navigator.of(context).maybePop(true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Submit failed: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Watching ensures rebuilds when fields change (e.g., if you prefill from elsewhere)
    final form = ref.watch(formStateProvider);
    final title =
        widget.title ?? (widget.formId != null ? 'Form: ${widget.formId}' : 'Contact Form');

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        centerTitle: true,
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight),
                child: IntrinsicHeight(
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        // Name
                        TextFormField(
                          controller: _nameCtrl,
                          decoration: const InputDecoration(
                            labelText: 'Full Name',
                            hintText: 'Enter your full name',
                            border: OutlineInputBorder(),
                          ),
                          textInputAction: TextInputAction.next,
                          onChanged: (v) => _updateField('fullName', v),
                          validator: (v) =>
                          (v == null || v.trim().isEmpty) ? 'Required' : null,
                        ),
                        const SizedBox(height: 12),

                        // Email
                        TextFormField(
                          controller: _emailCtrl,
                          decoration: const InputDecoration(
                            labelText: 'Email',
                            hintText: 'name@example.com',
                            border: OutlineInputBorder(),
                          ),
                          keyboardType: TextInputType.emailAddress,
                          textInputAction: TextInputAction.next,
                          onChanged: (v) => _updateField('email', v),
                          validator: (v) {
                            if (v == null || v.trim().isEmpty) return 'Required';
                            final ok = RegExp(r'^\S+@\S+\.\S+$').hasMatch(v.trim());
                            return ok ? null : 'Enter a valid email';
                          },
                        ),
                        const SizedBox(height: 12),

                        // Phone
                        TextFormField(
                          controller: _phoneCtrl,
                          decoration: const InputDecoration(
                            labelText: 'Phone',
                            hintText: '+1 555 555 5555',
                            border: OutlineInputBorder(),
                          ),
                          keyboardType: TextInputType.phone,
                          textInputAction: TextInputAction.next,
                          onChanged: (v) => _updateField('phone', v),
                        ),
                        const SizedBox(height: 12),

                        // Requirement
                        TextFormField(
                          controller: _notesCtrl,
                          decoration: const InputDecoration(
                            labelText: 'Requirement / Notes',
                            hintText: 'Tell us about your requirement',
                            border: OutlineInputBorder(),
                          ),
                          maxLines: 6,
                          minLines: 4,
                          textInputAction: TextInputAction.newline,
                          onChanged: (v) => _updateField('requirement', v),
                          validator: (v) =>
                          (v == null || v.trim().isEmpty) ? 'Required' : null,
                        ),

                        const Spacer(),

                        // Submit
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            icon: const Icon(Icons.send),
                            label: const Text('Submit'),
                            onPressed: _handleSubmit,
                          ),
                        ),

                        // Optional debug:
                        // const SizedBox(height: 8),
                        // Align(
                        //   alignment: Alignment.centerLeft,
                        //   child: Text(
                        //     'Debug: $form',
                        //     style: const TextStyle(fontSize: 12, color: Colors.black54),
                        //   ),
                        // ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
